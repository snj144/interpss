InterPSS V1.0-Bata Build4

Installation steps:

1. Check your Java installation

Launch a CMD window by Start/run/cmd. Type the following command

java -version

to make sure you have java version is 1.5.0_07 or above. 

If you do not have Java on your computer, please go to

http://java.sun.com/javase/downloads/index.jsp

to download Java JDK 5.0 updateX and install it to your computer.

2. Unzip the installation zip file to your computer.

3. Intall InterPSS by double-click/run the install.bat. You may need to modify 
the install.bat, if your Java installation is not in your Path.


InterPSS Developement Team
info@interpss.org
www.interpss.org
